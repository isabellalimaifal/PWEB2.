// URL das APIs públicas
const apiUrls = [
    'https://www.dnd5eapi.co/api/ability-scores/cha', // Carisma
    'https://api.spacexdata.com/v4/launches/latest', // SpaceX Último Lançamento
    'https://api.coindesk.com/v1/bpi/currentprice.json', // Bitcoin Price Index
    'https://dog.ceo/api/breeds/image/random' // Dog API (imagem aleatória de cachorro)
];

Promise.all(apiUrls.map(url => 
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error(`Erro na requisição: ${response.statusText}`);
            }
            return response.json();
        })
))
.then(dataArray => {
    dataArray.forEach((data, index) => {
        const section = document.getElementById(`section${index + 1}`);
        const title = document.createElement('h3');
        const content = document.createElement('p');

        if (index === 0) {
            // Processa dados de Carisma
            title.textContent = data.full_name;
            content.textContent = data.desc.join(' '); // Une a descrição
        } else if (index === 1) {
            // Processa dados do SpaceX
            title.textContent = "Último Lançamento da SpaceX";
            content.innerHTML = `
                <strong>Nome:</strong> ${data.name}<br>
                <strong>Data:</strong> ${new Date(data.date_utc).toLocaleString()}<br>
                <strong>Descrição:</strong> ${data.details || 'Sem detalhes.'}
            `;
        } else if (index === 2) {
            // Processa dados do Bitcoin Price Index
            title.textContent = "Preço Atual do Bitcoin";
            content.innerHTML = `
                <strong>Moeda:</strong> ${data.bpi.USD.code}<br>
                <strong>Preço:</strong> $${data.bpi.USD.rate}<br>
                <strong>Última Atualização:</strong> ${data.time.updated}
            `;
        } else if (index === 3) {
            // Processa dados do Dog API
            title.textContent = "Imagem Aleatória de Cachorro";
            content.innerHTML = `<img src="${data.message}" alt="Cachorro" style="max-width: 100%; height: auto;">`;
        }

        section.innerHTML = ''; // Limpa o conteúdo
        section.appendChild(title);
        section.appendChild(content);
    });
})
.catch(error => {
    console.error('Erro ao carregar os dados:', error);
    const errorSection = document.getElementById('errorSection'); // Crie uma seção para exibir erros
    errorSection.textContent = 'Erro ao carregar os dados: ' + error.message;
});
