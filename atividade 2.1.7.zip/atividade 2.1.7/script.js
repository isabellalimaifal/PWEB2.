document.getElementById('addRowBtn').addEventListener('click', function() {
    var tabela = document.getElementById('infoTable');
    var novaLinha = tabela.insertRow();
    var celula1 = novaLinha.insertCell(0);
    var celula2 = novaLinha.insertCell(1);
    celula1.textContent = 'João';
    celula2.textContent = '25';
});

document.getElementById('updateContentBtn').addEventListener('click', function() {
    var cabecalho = document.querySelector('#content h2');
    cabecalho.textContent = 'Conteúdo Atualizado';
    var novoParagrafo = document.createElement('p');
    novoParagrafo.textContent = 'Este é um novo parágrafo adicionado.';
    cabecalho.insertAdjacentElement('afterend', novoParagrafo);
});

document.getElementById('myLink').addEventListener('mouseover', function() {
    this.style.color = 'red';
});
document.getElementById('myLink').addEventListener('mouseout', function() {
    this.style.color = 'blue';
});

document.getElementById('addDivBtn').addEventListener('click', function() {
    var novaDiv = document.createElement('div');
    novaDiv.id = 'newDiv';
    novaDiv.textContent = 'Este é um novo bloco de conteúdo.';
    document.getElementById('content').appendChild(novaDiv);
});

document.getElementById('removeParagraphBtn').addEventListener('click', function() {
    var paragrafo = document.querySelector('#content p');
    if (paragrafo) {
        paragrafo.remove();
    }
});
